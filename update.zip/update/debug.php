<?php
echo "<h2>✅ PHP is working!</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>PDO Drivers: " . implode(', ', PDO::getAvailableDrivers()) . "</p>";

// Test DB connection
require_once __DIR__ . '/config/database.php';
try {
    $db = getDB();
    echo "<p style='color:green'>✅ MySQL connection OK</p>";
    $tables = $db->query("SHOW TABLES")->fetchAll();
    echo "<p>Tables: " . count($tables) . "</p><ul>";
    foreach ($tables as $t) {
        echo "<li>" . $t[0] . "</li>";
    }
    echo "</ul>";
} catch (Exception $e) {
    echo "<p style='color:red'>❌ DB Error: " . $e->getMessage() . "</p>";
}
echo "<p><a href='/pages/dashboard.php'>Go to Dashboard →</a></p>";
