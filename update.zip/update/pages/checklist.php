<?php
$pageTitle = 'Checklist Harian';
$activePage = 'checklist';
require_once __DIR__ . '/../includes/header.php';

$db = getDB();
$today = date('Y-m-d');

// Handle POST: mark done
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_done'])) {
    $cid = (int)$_POST['checklist_id'];
    $pic = !empty($_POST['pic']) ? $_POST['pic'] : currentUser()['full_name'];
    
    $stmt = $db->prepare("SELECT id FROM daily_checklist_logs WHERE checklist_id = ? AND log_date = ?");
    $stmt->execute(array($cid, $today));
    
    if ($stmt->fetch()) {
        $db->prepare("UPDATE daily_checklist_logs SET status = 'selesai', pic = ?, completed_at = NOW() WHERE checklist_id = ? AND log_date = ?")
           ->execute(array($pic, $cid, $today));
    } else {
        $db->prepare("INSERT INTO daily_checklist_logs (checklist_id, log_date, status, pic, completed_at) VALUES (?, ?, 'selesai', ?, NOW())")
           ->execute(array($cid, $today, $pic));
    }
    echo '<script>showToast("✅ Checklist selesai!","success")</script>';
}

$items = $db->query("SELECT dc.*, dl.status as log_status, dl.pic as log_pic, dl.completed_at FROM daily_checklist dc LEFT JOIN daily_checklist_logs dl ON dc.id = dl.checklist_id AND dl.log_date = '" . $today . "' WHERE dc.is_active = 1 ORDER BY dc.sort_order")->fetchAll();

$total = count($items);
$done = 0;
foreach ($items as $item) {
    if ($item['log_status'] === 'selesai') $done++;
}
$pct = $total > 0 ? round($done / $total * 100) : 0;
?>

<div class="alert alert-info d-flex align-items-center gap-2" style="font-size:13px">
  📌 Checklist harian wajib diisi setiap hari kerja. Jika ditemukan masalah, segera laporkan melalui tombol <strong>⚠️ Lapor DBR</strong>.
</div>

<div class="card border-0 shadow-sm mb-4" style="border-radius:12px">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <span class="fw-bold">Progres Hari Ini — <?php echo formatDate($today); ?></span>
      <span class="fw-bold"><?php echo $done; ?>/<?php echo $total; ?> Selesai (<?php echo $pct; ?>%)</span>
    </div>
    <div class="progress" style="height:10px;border-radius:5px">
      <div class="progress-bar <?php echo $pct === 100 ? 'bg-success' : 'bg-primary'; ?>" style="width:<?php echo $pct; ?>%;transition:width 0.5s"></div>
    </div>
  </div>
</div>

<div class="card border-0 shadow-sm" style="border-radius:12px">
  <div class="list-group list-group-flush">
    <?php foreach ($items as $item): 
      $isDone = ($item['log_status'] === 'selesai');
    ?>
    <div class="list-group-item d-flex align-items-center justify-content-between gap-3 py-3 px-3">
      <div class="flex-grow-1" style="min-width:0">
        <div class="fw-semibold" style="font-size:13px"><?php echo htmlspecialchars($item['task_name']); ?></div>
        <div class="text-muted" style="font-size:11px"><?php echo $item['schedule_info']; ?> · <?php echo $item['area']; ?></div>
        <?php if ($isDone): ?>
          <div class="text-success mt-1" style="font-size:11px">✅ Selesai oleh <strong><?php echo htmlspecialchars($item['log_pic']); ?></strong> — <?php echo timeAgo($item['completed_at']); ?></div>
        <?php endif; ?>
      </div>
      <div class="d-flex align-items-center gap-2 flex-shrink-0">
        <span class="badge <?php echo $isDone ? 'bg-success' : 'bg-light text-secondary'; ?>" style="font-size:10px">
          <?php echo $isDone ? '✓ Selesai' : '✗ Belum'; ?>
        </span>
        <?php if (!$isDone): ?>
        <form method="POST" class="d-flex align-items-center gap-2">
          <input type="hidden" name="checklist_id" value="<?php echo $item['id']; ?>">
          <select name="pic" class="form-select form-select-sm" style="font-size:11px;width:130px">
            <option value="">Pilih PIC</option>
            <option>Budi Santoso</option>
            <option>Dedi Kurniawan</option>
            <option>Agus Prasetyo</option>
            <option>Andi Rahman</option>
          </select>
          <button type="submit" name="mark_done" class="btn btn-success btn-sm" style="font-size:11px">✓ Selesai</button>
          <a href="/pages/dbr/" class="btn btn-danger btn-sm" style="font-size:11px;text-decoration:none">⚠️ Lapor DBR</a>
        </form>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
