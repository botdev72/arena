<?php
$pageTitle = 'Spare Parts';
$activePage = 'spareparts';
require_once __DIR__ . '/../includes/header.php';

$db = getDB();
$ss = getSparePartStats();
$parts = $db->query("SELECT * FROM spare_parts ORDER BY category, name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_stock'])) {
    $id = (int)$_POST['part_id'];
    $stock = (int)$_POST['stock'];
    $db->prepare("UPDATE spare_parts SET stock = ? WHERE id = ?")->execute(array($stock, $id));
    echo '<script>showToast("✅ Stok diupdate!","success")</script>';
    header("Location: spareparts.php");
    exit;
}
?>

<div class="row g-2 mb-4">
  <div class="col-md-4"><div class="card border-0 shadow-sm text-center p-3"><h3 class="fw-bold"><?php echo $ss['total']; ?></h3><small class="text-muted">Total Items</small></div></div>
  <div class="col-md-4"><div class="card border-0 shadow-sm text-center p-3"><h3 class="fw-bold text-danger"><?php echo $ss['low_stock']; ?></h3><small class="text-muted">⚠️ Low Stock</small></div></div>
  <div class="col-md-4"><div class="card border-0 shadow-sm text-center p-3"><h3 class="fw-bold">Rp 287M</h3><small class="text-muted">Nilai Inventory</small></div></div>
</div>

<div class="card border-0 shadow-sm" style="border-radius:12px">
  <div class="card-header bg-white py-3"><h6 class="fw-bold mb-0">📦 Daftar Spare Parts</h6></div>
  <div class="table-responsive">
    <table class="table table-hover mb-0" style="font-size:13px">
      <thead class="table-light">
        <tr><th>Kode</th><th>Nama</th><th>Kategori</th><th>Stok</th><th>Min</th><th>Satuan</th><th>Lokasi</th><th>Status</th></tr>
      </thead>
      <tbody>
        <?php foreach ($parts as $p): 
          $isLow = $p['stock'] < $p['min_stock'];
        ?>
        <tr>
          <td><strong><?php echo htmlspecialchars($p['code']); ?></strong></td>
          <td><?php echo htmlspecialchars($p['name']); ?></td>
          <td><span class="badge bg-light text-dark"><?php echo $p['category']; ?></span></td>
          <td><strong class="<?php echo $isLow ? 'text-danger' : ''; ?>"><?php echo $p['stock']; ?></strong></td>
          <td><?php echo $p['min_stock']; ?></td>
          <td><?php echo $p['unit']; ?></td>
          <td><?php echo htmlspecialchars($p['location']); ?></td>
          <td><span class="badge <?php echo $isLow ? 'bg-danger' : 'bg-success'; ?>"><?php echo $isLow ? '⚠️ Low Stock' : '✅ Aman'; ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
