<?php
$pageTitle = 'Dashboard';
$activePage = 'dashboard';
require_once __DIR__ . '/../includes/header.php';

$dbrS = getDBRStats();
$cl = getChecklistProgress();
$eq = getEquipmentStats();
$mt = getMeterStats();
$sp = getSparePartStats();
$db = getDB();

$rec = $db->query("SELECT d.dbr_number, u.name as unit_name, d.problem, d.pic, d.status, d.down_date, d.down_time FROM dbr d JOIN units u ON d.unit_id = u.id ORDER BY d.created_at DESC LIMIT 5")->fetchAll();

$today = date('Y-m-d');
$stmt = $db->prepare("SELECT dc.task_name, dl.status, dl.pic, dl.completed_at, dc.area FROM daily_checklist dc LEFT JOIN daily_checklist_logs dl ON dc.id = dl.checklist_id AND dl.log_date = ? WHERE dc.is_active = 1 ORDER BY dc.sort_order");
$stmt->execute(array($today));
$di = $stmt->fetchAll();
?>

<!-- KPI Cards -->
<div class="row g-3 mb-4">
  <div class="col-xl-3 col-md-6">
    <div class="card border-0 shadow-sm card-stat h-100" style="border-radius:12px">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-start mb-2">
          <span class="rounded-2 d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary" style="width:40px;height:40px;font-size:20px">📋</span>
          <small class="text-success fw-semibold">&uarr; 8%</small>
        </div>
        <h3 class="fw-bold mb-0"><?php echo $dbrS['total']; ?></h3>
        <small class="text-muted">Total DBR Bulan Ini</small>
        <div class="mt-2"><span class="text-warning fw-bold"><?php echo $dbrS['open_total']; ?></span> <small class="text-muted">laporan terbuka</small></div>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-md-6">
    <div class="card border-0 shadow-sm card-stat h-100" style="border-radius:12px">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-start mb-2">
          <span class="rounded-2 d-inline-flex align-items-center justify-content-center bg-success bg-opacity-10 text-success" style="width:40px;height:40px;font-size:20px">✅</span>
          <small class="text-success fw-semibold">&uarr; 12%</small>
        </div>
        <h3 class="fw-bold mb-0"><?php echo $dbrS['Closed']; ?></h3>
        <small class="text-muted">DBR Terselesaikan</small>
        <?php $pctClosed = $dbrS['total'] > 0 ? round($dbrS['Closed'] / $dbrS['total'] * 100) : 0; ?>
        <div class="progress mt-2" style="height:6px;border-radius:3px">
          <div class="progress-bar bg-success" style="width:<?php echo $pctClosed; ?>%"></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-md-6">
    <div class="card border-0 shadow-sm card-stat h-100" style="border-radius:12px">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-start mb-2">
          <span class="rounded-2 d-inline-flex align-items-center justify-content-center bg-info bg-opacity-10 text-info" style="width:40px;height:40px;font-size:20px">✅</span>
        </div>
        <h3 class="fw-bold mb-0"><?php echo $cl['done']; ?>/<?php echo $cl['total']; ?></h3>
        <small class="text-muted">Checklist Harian Selesai</small>
        <div class="progress mt-2" style="height:6px;border-radius:3px">
          <div class="progress-bar bg-info" style="width:<?php echo $cl['pct']; ?>%"></div>
        </div>
        <small class="text-muted mt-1 d-block"><?php echo $cl['pct']; ?>% selesai hari ini</small>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-md-6">
    <div class="card border-0 shadow-sm card-stat h-100" style="border-radius:12px">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-start mb-2">
          <span class="rounded-2 d-inline-flex align-items-center justify-content-center bg-warning bg-opacity-10 text-warning" style="width:40px;height:40px;font-size:20px">⚙️</span>
        </div>
        <h3 class="fw-bold mb-0"><?php echo $eq['running']; ?>/<?php echo $eq['total']; ?></h3>
        <small class="text-muted">Peralatan Running</small>
        <div class="mt-2">
          <?php if ($eq['maintenance'] > 0): ?><span class="badge bg-warning text-dark me-1"><?php echo $eq['maintenance']; ?> Mnt</span><?php endif; ?>
          <?php if ($eq['stopped'] > 0): ?><span class="badge bg-danger me-1"><?php echo $eq['stopped']; ?> Stop</span><?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Feature Cards -->
<div class="row g-3 mb-4">
  <div class="col-lg-4">
    <a href="/pages/dbr/" class="text-decoration-none">
      <div class="card border-0 shadow-sm h-100" style="border-radius:12px">
        <div class="card-body p-4">
          <div style="font-size:36px;margin-bottom:8px">🔴</div>
          <h5 class="fw-bold text-dark">Laporan DBR</h5>
          <p class="text-muted" style="font-size:13px">Catat, lihat, dan kelola semua laporan kerusakan unit secara terpusat.</p>
          <div class="bg-warning bg-opacity-10 text-warning rounded-2 px-3 py-2 fw-semibold" style="font-size:13px">
            Laporan Terbuka Saat Ini: <strong class="fs-5"><?php echo $dbrS['open_total']; ?></strong>
          </div>
        </div>
      </div>
    </a>
  </div>
  <div class="col-lg-4">
    <a href="/pages/checklist.php" class="text-decoration-none">
      <div class="card border-0 shadow-sm h-100" style="border-radius:12px">
        <div class="card-body p-4">
          <div style="font-size:36px;margin-bottom:8px">✅</div>
          <h5 class="fw-bold text-dark">Checklist Harian ME</h5>
          <p class="text-muted" style="font-size:13px">Lacak dan perbarui status pekerjaan rutin harian seluruh peralatan ME.</p>
          <div class="bg-info bg-opacity-10 text-info rounded-2 px-3 py-2 fw-semibold" style="font-size:13px">
            Progres Hari Ini: <strong class="fs-5"><?php echo $cl['done']; ?></strong> dari <strong class="fs-5"><?php echo $cl['total']; ?></strong> Selesai
          </div>
        </div>
      </div>
    </a>
  </div>
  <div class="col-lg-4">
    <a href="/pages/meteran.php" class="text-decoration-none">
      <div class="card border-0 shadow-sm h-100" style="border-radius:12px">
        <div class="card-body p-4">
          <div style="font-size:36px;margin-bottom:8px">💧</div>
          <h5 class="fw-bold text-dark">Catatan Meteran</h5>
          <p class="text-muted" style="font-size:13px">Pantau pemakaian listrik, air, dan utilitas dari semua titik distribusi.</p>
          <div class="bg-success bg-opacity-10 text-success rounded-2 px-3 py-2 fw-semibold" style="font-size:13px">
            Lokasi Tercatat Hari Ini: <strong class="fs-5"><?php echo $mt['recorded']; ?></strong> / <?php echo $mt['total']; ?>
          </div>
        </div>
      </div>
    </a>
  </div>
</div>

<!-- Recent DBR + Checklist -->
<div class="row g-3 mb-4">
  <div class="col-lg-8">
    <div class="card border-0 shadow-sm" style="border-radius:12px">
      <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center py-3" style="border-radius:12px 12px 0 0">
        <h6 class="fw-bold mb-0">📋 Laporan DBR Terakhir Masuk</h6>
        <a href="/pages/dbr/" class="text-decoration-none fw-semibold" style="font-size:12px">Lihat Semua →</a>
      </div>
      <div class="table-responsive">
        <table class="table table-hover mb-0" style="font-size:13px">
          <thead class="table-light">
            <tr><th>ID</th><th>Unit</th><th>Problem</th><th>PIC</th><th>Status</th><th>Down</th></tr>
          </thead>
          <tbody>
            <?php foreach ($rec as $d): 
              $problem = mb_strlen($d['problem']) > 50 ? mb_substr($d['problem'], 0, 50) . '...' : $d['problem'];
              $picName = $d['pic'] ? $d['pic'] : '-';
            ?>
            <tr>
              <td><strong><?php echo htmlspecialchars($d['dbr_number']); ?></strong></td>
              <td><?php echo htmlspecialchars($d['unit_name']); ?></td>
              <td><?php echo htmlspecialchars($problem); ?></td>
              <td><?php echo htmlspecialchars($picName); ?></td>
              <td><?php echo statusBadge($d['status']); ?></td>
              <td style="font-size:11px"><?php echo formatDate($d['down_date']); ?>, <?php echo substr($d['down_time'], 0, 5); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card border-0 shadow-sm" style="border-radius:12px">
      <div class="card-header bg-white border-bottom py-3" style="border-radius:12px 12px 0 0">
        <h6 class="fw-bold mb-0">✅ Tugas Harian Hari Ini</h6>
      </div>
      <div class="list-group list-group-flush" style="max-height:340px;overflow-y:auto">
        <?php foreach ($di as $item): 
          $isDone = ($item['status'] === 'selesai');
        ?>
        <div class="list-group-item border-0 border-bottom py-2 px-3">
          <div class="d-flex justify-content-between align-items-start gap-2">
            <div class="flex-grow-1" style="min-width:0">
              <div class="fw-semibold" style="font-size:12px"><?php echo htmlspecialchars($item['task_name']); ?></div>
              <?php if ($isDone): ?>
                <small class="text-success">✅ <?php echo htmlspecialchars($item['pic']); ?> — <?php echo timeAgo($item['completed_at']); ?></small>
              <?php else: ?>
                <small class="text-muted">Belum ada laporan · <?php echo htmlspecialchars($item['area']); ?></small>
              <?php endif; ?>
            </div>
            <span class="badge <?php echo $isDone ? 'bg-success' : 'bg-light text-secondary'; ?> flex-shrink-0" style="font-size:10px">
              <?php echo $isDone ? '✓ Selesai' : '✗ Belum'; ?>
            </span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- Stats -->
<div class="row g-3 mb-4">
  <div class="col-md-3"><div class="card border-0 shadow-sm text-center p-3" style="border-radius:12px"><small class="text-muted">⚡ Listrik Hari Ini</small><h3 class="fw-bold mb-0">380.5 <small style="font-size:12px;color:#888">kWh</small></h3></div></div>
  <div class="col-md-3"><div class="card border-0 shadow-sm text-center p-3" style="border-radius:12px"><small class="text-muted">💧 Air Hari Ini</small><h3 class="fw-bold mb-0">110.5 <small style="font-size:12px;color:#888">m³</small></h3></div></div>
  <div class="col-md-3"><div class="card border-0 shadow-sm text-center p-3" style="border-radius:12px"><small class="text-muted">📦 Spare Parts</small><h3 class="fw-bold mb-0"><?php echo $sp['total']; ?> <small style="font-size:12px;color:#888">items</small></h3><?php if ($sp['low_stock'] > 0): ?><small class="text-danger">⚠️ <?php echo $sp['low_stock']; ?> low stock</small><?php endif; ?></div></div>
  <div class="col-md-3"><div class="card border-0 shadow-sm text-center p-3" style="border-radius:12px"><small class="text-muted">🛢️ BBM Genset</small><h3 class="fw-bold mb-0">450 <small style="font-size:12px;color:#888">Liter</small></h3></div></div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
