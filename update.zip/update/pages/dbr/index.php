<?php
$pageTitle = 'Laporan DBR';
$activePage = 'dbr';
require_once __DIR__ . '/../../includes/header.php';

$db = getDB();
$dbrS = getDBRStats();
$units = $db->query("SELECT id, code, name, area FROM units ORDER BY name")->fetchAll();
$users = $db->query("SELECT full_name FROM users WHERE active = 1 ORDER BY full_name")->fetchAll();

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = isset($_POST['_action']) ? $_POST['_action'] : '';
    
    if ($act === 'create') {
        $mx = $db->query("SELECT MAX(CAST(REPLACE(dbr_number, 'DBR-', '') AS UNSIGNED)) FROM dbr")->fetchColumn();
        $nx = str_pad(($mx ? (int)$mx : 0) + 1, 3, '0', STR_PAD_LEFT);
        $newNum = 'DBR-' . $nx;
        
        $rd = !empty($_POST['ready_date']) ? $_POST['ready_date'] : null;
        $rt = !empty($_POST['ready_time']) ? $_POST['ready_time'] . ':00' : null;
        $userFull = currentUser()['full_name'];
        
        $db->prepare("INSERT INTO dbr (dbr_number, unit_id, category, down_date, down_hm, down_time, ready_date, ready_hm, ready_time, problem, action, pic, status, keterangan, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
           ->execute(array($newNum, $_POST['unit_id'], $_POST['category'], $_POST['down_date'], 
               (int)$_POST['down_hm'], $_POST['down_time'] . ':00', $rd, (int)$_POST['ready_hm'], 
               $rt, $_POST['problem'], $_POST['action_text'], $_POST['pic'], $_POST['status'], 
               isset($_POST['keterangan']) ? $_POST['keterangan'] : '', $userFull));
        echo '<script>showToast("✅ ' . $newNum . ' berhasil dibuat!","success")</script>';
    }
    
    if ($act === 'update' && !empty($_POST['dbr_id'])) {
        $rd = !empty($_POST['ready_date']) ? $_POST['ready_date'] : null;
        $rt = !empty($_POST['ready_time']) ? $_POST['ready_time'] . ':00' : null;
        $ket = isset($_POST['keterangan']) ? $_POST['keterangan'] : '';
        
        $db->prepare("UPDATE dbr SET unit_id = ?, category = ?, down_date = ?, down_hm = ?, down_time = ?, ready_date = ?, ready_hm = ?, ready_time = ?, problem = ?, action = ?, pic = ?, status = ?, keterangan = ? WHERE id = ?")
           ->execute(array($_POST['unit_id'], $_POST['category'], $_POST['down_date'], 
               (int)$_POST['down_hm'], $_POST['down_time'] . ':00', $rd, (int)$_POST['ready_hm'], 
               $rt, $_POST['problem'], $_POST['action_text'], $_POST['pic'], 
               $_POST['status'], $ket, (int)$_POST['dbr_id']));
        echo '<script>showToast("✅ DBR berhasil diupdate!","success")</script>';
    }
    
    if ($act === 'delete' && !empty($_POST['dbr_id'])) {
        $db->prepare("DELETE FROM dbr WHERE id = ?")->execute(array((int)$_POST['dbr_id']));
        echo '<script>showToast("🗑️ DBR dihapus!","warning")</script>';
    }
}

// Search/filter
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sf = isset($_GET['status']) ? $_GET['status'] : '';

$sql = "SELECT d.*, u.name as unit_name FROM dbr d JOIN units u ON d.unit_id = u.id WHERE 1 = 1";
$params = array();

if ($search !== '') {
    $sql .= " AND (d.problem LIKE ? OR d.action LIKE ? OR u.name LIKE ? OR d.pic LIKE ?)";
    $s = '%' . $search . '%';
    $params[] = $s; $params[] = $s; $params[] = $s; $params[] = $s;
}
if ($sf !== '' && $sf !== 'all') {
    $sql .= " AND d.status = ?";
    $params[] = $sf;
}
$sql .= " ORDER BY d.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$list = $stmt->fetchAll();
?>

<!-- DBR Stats -->
<div class="row g-2 mb-4">
  <?php 
  $statuses = array('Open' => 'warning', 'In Progress' => 'info', 'Pending Part' => 'danger', 'Monitoring' => 'purple', 'Closed' => 'success');
  foreach ($statuses as $k => $c): ?>
  <div class="col">
    <a href="?status=<?php echo urlencode($k); ?>" class="text-decoration-none">
      <div class="card border-0 shadow-sm text-center py-2" style="border-radius:10px;cursor:pointer">
        <h4 class="fw-bold mb-0"><?php echo $dbrS[$k]; ?></h4>
        <small class="text-muted" style="font-size:11px"><?php echo $k; ?></small>
      </div>
    </a>
  </div>
  <?php endforeach; ?>
</div>

<!-- Form -->
<div class="card border-0 shadow-sm mb-4" style="border-radius:12px" id="formCard">
  <div class="card-header bg-white d-flex justify-content-between align-items-center py-3" style="border-radius:12px 12px 0 0">
    <h6 class="fw-bold mb-0" id="formTitle">➕ Tambah Data Kerusakan Baru</h6>
    <button class="btn btn-sm btn-outline-secondary" onclick="document.getElementById('formBody').classList.toggle('d-none')">Toggle Form</button>
  </div>
  <div class="card-body" id="formBody">
    <form method="POST" id="dbrForm">
      <input type="hidden" name="_action" id="formAction" value="create">
      <input type="hidden" name="dbr_id" id="formDbrId" value="">
      
      <div class="row g-3 mb-3">
        <div class="col-md-4">
          <label class="form-label fw-semibold" style="font-size:12px">Unit <span class="text-danger">*</span></label>
          <select name="unit_id" id="fUnitId" class="form-select" required>
            <option value="">Pilih Unit</option>
            <?php foreach ($units as $u): ?>
            <option value="<?php echo $u['id']; ?>"><?php echo htmlspecialchars($u['name']); ?> (<?php echo $u['area']; ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label fw-semibold" style="font-size:12px">Kategori</label>
          <select name="category" id="fCategory" class="form-select" required>
            <option>Mekanikal</option><option>Elektrikal</option>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label fw-semibold" style="font-size:12px">PIC <span class="text-danger">*</span></label>
          <select name="pic" id="fPic" class="form-select">
            <option value="">Pilih PIC</option>
            <?php foreach ($users as $u): ?>
            <option><?php echo htmlspecialchars($u['full_name']); ?></option>
            <?php endforeach; ?>
            <option>ALL TEAM</option>
          </select>
        </div>
      </div>
      
      <div class="row g-3 mb-2">
        <div class="col-md-4"><label class="form-label fw-semibold" style="font-size:12px">Tgl Down <span class="text-danger">*</span></label><input type="date" name="down_date" id="fDownDate" class="form-control" value="<?php echo date('Y-m-d'); ?>" required></div>
        <div class="col-md-2"><label class="form-label fw-semibold" style="font-size:12px">HM</label><input type="number" name="down_hm" id="fDownHM" class="form-control" value="0"></div>
        <div class="col-md-2"><label class="form-label fw-semibold" style="font-size:12px">Jam <span class="text-danger">*</span></label><input type="time" name="down_time" id="fDownTime" class="form-control" value="08:00" required></div>
        <div class="col-md-2"><label class="form-label fw-semibold" style="font-size:12px">Tgl Ready</label><input type="date" name="ready_date" id="fReadyDate" class="form-control"></div>
        <div class="col-md-1"><label class="form-label fw-semibold" style="font-size:12px">HM</label><input type="number" name="ready_hm" id="fReadyHM" class="form-control" value="0"></div>
        <div class="col-md-1"><label class="form-label fw-semibold" style="font-size:12px">Jam</label><input type="time" name="ready_time" id="fReadyTime" class="form-control"></div>
      </div>
      
      <div class="row g-3 mb-3">
        <div class="col-md-6"><label class="form-label fw-semibold" style="font-size:12px">Problem <span class="text-danger">*</span></label><textarea name="problem" id="fProblem" class="form-control" rows="2" required placeholder="Deskripsikan kerusakan..."></textarea></div>
        <div class="col-md-6"><label class="form-label fw-semibold" style="font-size:12px">Action <span class="text-danger">*</span></label><textarea name="action_text" id="fAction" class="form-control" rows="2" required placeholder="Tindakan perbaikan..."></textarea></div>
      </div>
      
      <div class="row g-3 mb-3">
        <div class="col-md-6"><label class="form-label fw-semibold" style="font-size:12px">Status</label><select name="status" id="fStatus" class="form-select"><option>Open</option><option>In Progress</option><option>Pending Part</option><option>Monitoring</option><option>Closed</option></select></div>
        <div class="col-md-6"><label class="form-label fw-semibold" style="font-size:12px">Keterangan</label><input type="text" name="keterangan" id="fKeterangan" class="form-control" placeholder="Catatan tambahan..."></div>
      </div>
      
      <button type="submit" class="btn btn-primary fw-semibold" id="formSubmitBtn">💾 Simpan DBR</button>
      <button type="button" class="btn btn-outline-secondary ms-2" onclick="resetForm()">Reset</button>
    </form>
  </div>
</div>

<!-- Table -->
<div class="card border-0 shadow-sm" style="border-radius:12px">
  <div class="card-header bg-white d-flex justify-content-between align-items-center py-3" style="border-radius:12px 12px 0 0">
    <h6 class="fw-bold mb-0">📋 Data Breakdown Tercatat (<?php echo count($list); ?>)</h6>
    <form method="GET" class="d-flex gap-2">
      <?php if ($sf): ?><input type="hidden" name="status" value="<?php echo htmlspecialchars($sf); ?>"><?php endif; ?>
      <input type="text" name="search" class="form-control form-control-sm" placeholder="🔍 Cari DBR..." value="<?php echo htmlspecialchars($search); ?>" style="width:200px">
      <button class="btn btn-sm btn-outline-secondary">Cari</button>
      <?php if ($search || $sf): ?><a href="?" class="btn btn-sm btn-outline-danger">✕ Reset</a><?php endif; ?>
    </form>
  </div>
  <div class="table-responsive">
    <table class="table table-hover mb-0" style="font-size:13px">
      <thead class="table-light">
        <tr><th>No</th><th>Unit</th><th>Waktu Down</th><th>Waktu Ready</th><th>Problem</th><th>Action</th><th>PIC</th><th>Status</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach ($list as $d): 
          $prob = mb_strlen($d['problem']) > 35 ? mb_substr($d['problem'], 0, 35) . '...' : $d['problem'];
          $act = mb_strlen($d['action']) > 35 ? mb_substr($d['action'], 0, 35) . '...' : $d['action'];
          $ready = $d['ready_date'] ? formatDate($d['ready_date']) . ', ' . substr($d['ready_time'], 0, 5) : '-';
          $dbrJson = htmlspecialchars(json_encode($d));
        ?>
        <tr>
          <td><strong><?php echo htmlspecialchars($d['dbr_number']); ?></strong></td>
          <td><?php echo htmlspecialchars($d['unit_name']); ?></td>
          <td style="font-size:11px"><?php echo formatDate($d['down_date']); ?>, <?php echo substr($d['down_time'], 0, 5); ?></td>
          <td style="font-size:11px"><?php echo $ready; ?></td>
          <td><?php echo htmlspecialchars($prob); ?></td>
          <td><?php echo htmlspecialchars($act); ?></td>
          <td><?php echo htmlspecialchars($d['pic'] ? $d['pic'] : '-'); ?></td>
          <td><?php echo statusBadge($d['status']); ?></td>
          <td nowrap>
            <button class="btn btn-sm btn-outline-secondary" onclick='editDBR(<?php echo $dbrJson; ?>)' title="Edit" style="font-size:12px">✏️</button>
            <form method="POST" style="display:inline" onsubmit="return confirmDelete()">
              <input type="hidden" name="_action" value="delete">
              <input type="hidden" name="dbr_id" value="<?php echo $d['id']; ?>">
              <button class="btn btn-sm btn-outline-danger" title="Hapus" style="font-size:12px">🗑️</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
function editDBR(d) {
  document.getElementById('formTitle').textContent = '✏️ Edit ' + d.dbr_number;
  document.getElementById('formAction').value = 'update';
  document.getElementById('formDbrId').value = d.id;
  document.getElementById('formSubmitBtn').textContent = '💾 Update DBR';
  document.getElementById('fUnitId').value = d.unit_id;
  document.getElementById('fCategory').value = d.category;
  document.getElementById('fPic').value = d.pic || '';
  document.getElementById('fDownDate').value = d.down_date;
  document.getElementById('fDownHM').value = d.down_hm;
  document.getElementById('fDownTime').value = d.down_time ? d.down_time.substring(0,5) : '08:00';
  document.getElementById('fReadyDate').value = d.ready_date || '';
  document.getElementById('fReadyHM').value = d.ready_hm || 0;
  document.getElementById('fReadyTime').value = d.ready_time ? d.ready_time.substring(0,5) : '';
  document.getElementById('fProblem').value = d.problem;
  document.getElementById('fAction').value = d.action;
  document.getElementById('fStatus').value = d.status;
  document.getElementById('fKeterangan').value = d.keterangan || '';
  document.getElementById('formBody').classList.remove('d-none');
  document.getElementById('formCard').scrollIntoView({behavior:'smooth'});
}
function resetForm() {
  document.getElementById('formTitle').textContent = '➕ Tambah Data Kerusakan Baru';
  document.getElementById('formAction').value = 'create';
  document.getElementById('formDbrId').value = '';
  document.getElementById('formSubmitBtn').textContent = '💾 Simpan DBR';
  document.getElementById('dbrForm').reset();
  document.getElementById('fDownDate').value = '<?php echo date("Y-m-d"); ?>';
  document.getElementById('fDownTime').value = '08:00';
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
