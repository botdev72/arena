<?php
$pageTitle = 'Catatan Meteran';
$activePage = 'meteran';
require_once __DIR__ . '/../includes/header.php';

$db = getDB();
$today = date('Y-m-d');

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_meter'])) {
    $date = !empty($_POST['reading_date']) ? $_POST['reading_date'] : $today;
    $pic = !empty($_POST['pic']) ? $_POST['pic'] : currentUser()['full_name'];
    $locs = $db->query("SELECT * FROM meter_locations WHERE is_active = 1 ORDER BY meter_type, sort_order")->fetchAll();
    $saved = 0;
    foreach ($locs as $loc) {
        $key = 'meter_' . $loc['code'];
        if (isset($_POST[$key]) && $_POST[$key] !== '') {
            $val = (float)$_POST[$key];
            // Delete existing
            $db->prepare("DELETE FROM meter_readings WHERE reading_date = ? AND location_code = ?")
               ->execute(array($date, $loc['code']));
            // Get previous
            $pr = $db->prepare("SELECT meter_value FROM meter_readings WHERE reading_date < ? AND location_code = ? ORDER BY reading_date DESC LIMIT 1");
            $pr->execute(array($date, $loc['code']));
            $pv = $pr->fetchColumn();
            if ($pv === false) $pv = $val;
            $usage = max(0, $val - $pv);
            $db->prepare("INSERT INTO meter_readings (reading_date, location_code, meter_type, meter_value, usage_value, pic) VALUES (?, ?, ?, ?, ?, ?)")
               ->execute(array($date, $loc['code'], $loc['meter_type'], $val, $usage, $pic));
            $saved++;
        }
    }
    echo '<script>showToast("✅ ' . $saved . ' data meteran tersimpan!","success")</script>';
}

$locs = $db->query("SELECT * FROM meter_locations WHERE is_active = 1 ORDER BY meter_type, sort_order")->fetchAll();

// Today's readings
$tv = array();
$tr = $db->prepare("SELECT location_code, meter_value FROM meter_readings WHERE reading_date = ?");
$tr->execute(array($today));
foreach ($tr->fetchAll() as $r) {
    $tv[$r['location_code']] = $r['meter_value'];
}

// Count by type
$counts = array('listrik' => array('total' => 0, 'done' => 0), 'air' => array('total' => 0, 'done' => 0), 'bahan_bakar' => array('total' => 0, 'done' => 0));
foreach ($locs as $loc) {
    $t = $loc['meter_type'];
    $counts[$t]['total']++;
    if (isset($tv[$loc['code']])) $counts[$t]['done']++;
}
?>

<div class="row g-3 mb-4">
  <div class="col-lg-8">
    <div class="card border-0 shadow-sm" style="border-radius:12px">
      <div class="card-header bg-white py-3"><h6 class="fw-bold mb-0">📝 Input Data Meteran — <?php echo formatDate($today); ?></h6></div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="save_meter" value="1">
          <div class="row g-3 mb-3">
            <div class="col-md-6"><label class="form-label fw-semibold" style="font-size:12px">Tanggal</label><input type="date" name="reading_date" class="form-control" value="<?php echo $today; ?>"></div>
            <div class="col-md-6"><label class="form-label fw-semibold" style="font-size:12px">PIC</label>
              <select name="pic" class="form-select">
                <option value="">Pilih PIC</option>
                <option>Budi Santoso</option><option>Dedi Kurniawan</option><option>Agus Prasetyo</option><option>Andi Rahman</option>
              </select>
            </div>
          </div>
          
          <?php
          $currentType = '';
          $typeLabels = array('listrik' => '⚡ Listrik (kWh)', 'air' => '💧 Air Bersih (m³)', 'bahan_bakar' => '🛢️ BBM Genset (Liter)');
          foreach ($locs as $loc):
            if ($loc['meter_type'] !== $currentType):
              if ($currentType !== '') echo '</div>';
              $currentType = $loc['meter_type'];
              echo '<h6 class="fw-bold mt-2 mb-2">' . (isset($typeLabels[$currentType]) ? $typeLabels[$currentType] : $currentType) . '</h6><div class="row g-2">';
            endif;
            $val = isset($tv[$loc['code']]) ? $tv[$loc['code']] : '';
          ?>
            <div class="col-md-3">
              <label class="form-label" style="font-size:11px"><?php echo htmlspecialchars($loc['name']); ?></label>
              <input type="number" step="0.01" name="meter_<?php echo $loc['code']; ?>" class="form-control form-control-sm" value="<?php echo $val; ?>" placeholder="<?php echo $loc['unit']; ?>">
            </div>
          <?php endforeach; echo '</div>'; ?>
          
          <button type="submit" class="btn btn-primary fw-semibold mt-3">💾 Simpan Semua Data Meteran</button>
        </form>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card border-0 shadow-sm" style="border-radius:12px">
      <div class="card-header bg-white py-3"><h6 class="fw-bold mb-0">📊 Ringkasan Hari Ini</h6></div>
      <div class="list-group list-group-flush">
        <?php foreach (array('listrik' => '⚡ Listrik', 'air' => '💧 Air', 'bahan_bakar' => '🛢️ BBM') as $tp => $lb): ?>
        <div class="list-group-item d-flex justify-content-between align-items-center">
          <span><?php echo $lb; ?></span>
          <span class="badge <?php echo $counts[$tp]['done'] === $counts[$tp]['total'] ? 'bg-success' : 'bg-warning text-dark'; ?>">
            <?php echo $counts[$tp]['done']; ?>/<?php echo $counts[$tp]['total']; ?>
          </span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
