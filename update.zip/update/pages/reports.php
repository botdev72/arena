<?php
$pageTitle = 'Laporan & Analitik';
$activePage = 'reports';
require_once __DIR__ . '/../includes/header.php';

$ds = getDBRStats();
$es = getEquipmentStats();
$oee = $es['total'] > 0 ? round($es['running'] / $es['total'] * 100) : 0;
?>

<div class="row g-3 mb-4">
  <div class="col-lg-4"><div class="card border-0 shadow-sm text-center p-4" style="border-radius:12px"><div style="font-size:48px;margin-bottom:8px">📊</div><h5 class="fw-bold">Laporan Bulanan</h5><p class="text-muted" style="font-size:13px">Ringkasan WO, downtime, dan OEE</p><button class="btn btn-primary btn-sm">Generate →</button></div></div>
  <div class="col-lg-4"><div class="card border-0 shadow-sm text-center p-4" style="border-radius:12px"><div style="font-size:48px;margin-bottom:8px">⚠️</div><h5 class="fw-bold">Analisis Breakdown</h5><p class="text-muted" style="font-size:13px">MTBF, MTTR, dan root cause analysis</p><button class="btn btn-primary btn-sm">Generate →</button></div></div>
  <div class="col-lg-4"><div class="card border-0 shadow-sm text-center p-4" style="border-radius:12px"><div style="font-size:48px;margin-bottom:8px">💰</div><h5 class="fw-bold">Laporan Biaya</h5><p class="text-muted" style="font-size:13px">Biaya maintenance & spare parts</p><button class="btn btn-primary btn-sm">Generate →</button></div></div>
</div>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="card border-0 shadow-sm" style="border-radius:12px">
      <div class="card-header bg-white py-3"><h6 class="fw-bold mb-0">📊 Ringkasan DBR Bulan Ini</h6></div>
      <div class="card-body">
        <?php 
        $statusColors = array('Open' => 'warning', 'In Progress' => 'info', 'Pending Part' => 'danger', 'Monitoring' => 'purple', 'Closed' => 'success');
        foreach ($statusColors as $status => $color): 
          $pct = $ds['total'] > 0 ? round($ds[$status] / $ds['total'] * 100) : 0;
        ?>
        <div class="d-flex justify-content-between align-items-center mb-2">
          <span class="fw-semibold" style="font-size:13px"><?php echo $status; ?></span>
          <div class="d-flex align-items-center gap-2">
            <div class="progress flex-grow-1" style="width:200px;height:8px;border-radius:4px">
              <div class="progress-bar bg-<?php echo $color; ?>" style="width:<?php echo $pct; ?>%"></div>
            </div>
            <strong style="font-size:14px"><?php echo $ds[$status]; ?></strong>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card border-0 shadow-sm" style="border-radius:12px">
      <div class="card-header bg-white py-3"><h6 class="fw-bold mb-0">⚙️ Status Peralatan</h6></div>
      <div class="card-body text-center">
        <div class="row g-2">
          <div class="col-6"><h1 class="fw-bold text-success"><?php echo $es['running']; ?></h1><small class="text-muted">Running</small></div>
          <div class="col-6"><h1 class="fw-bold text-warning"><?php echo $es['maintenance']; ?></h1><small class="text-muted">Maintenance</small></div>
          <div class="col-6"><h1 class="fw-bold text-secondary"><?php echo $es['standby']; ?></h1><small class="text-muted">Standby</small></div>
          <div class="col-6"><h1 class="fw-bold text-danger"><?php echo $es['stopped']; ?></h1><small class="text-muted">Stopped</small></div>
        </div>
        <div class="mt-3 p-3 bg-light rounded-2">
          <small class="text-muted">Overall Equipment Availability</small>
          <h2 class="fw-bold mb-0"><?php echo $oee; ?>%</h2>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
