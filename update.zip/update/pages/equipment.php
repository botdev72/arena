<?php
$pageTitle = 'Peralatan';
$activePage = 'equipment';
require_once __DIR__ . '/../includes/header.php';

$db = getDB();
$es = getEquipmentStats();
$units = $db->query("SELECT * FROM units ORDER BY area, name")->fetchAll();
$statusLabels = array('running' => '🟢 Running', 'maintenance' => '🟡 Maintenance', 'stopped' => '🔴 Stopped', 'standby' => '⚪ Standby');
?>

<div class="row g-2 mb-4">
  <div class="col"><div class="card border-0 shadow-sm text-center p-2"><h4 class="fw-bold"><?php echo $es['total']; ?></h4><small class="text-muted">Total</small></div></div>
  <div class="col"><div class="card border-0 shadow-sm text-center p-2"><h4 class="fw-bold text-success"><?php echo $es['running']; ?></h4><small class="text-muted">Running</small></div></div>
  <div class="col"><div class="card border-0 shadow-sm text-center p-2"><h4 class="fw-bold text-warning"><?php echo $es['maintenance']; ?></h4><small class="text-muted">Maintenance</small></div></div>
  <div class="col"><div class="card border-0 shadow-sm text-center p-2"><h4 class="fw-bold text-secondary"><?php echo $es['standby']; ?></h4><small class="text-muted">Standby</small></div></div>
  <div class="col"><div class="card border-0 shadow-sm text-center p-2"><h4 class="fw-bold text-danger"><?php echo $es['stopped']; ?></h4><small class="text-muted">Stopped</small></div></div>
</div>

<div class="card border-0 shadow-sm" style="border-radius:12px">
  <div class="card-header bg-white py-3"><h6 class="fw-bold mb-0">⚙️ Semua Unit (<?php echo count($units); ?>)</h6></div>
  <div class="table-responsive">
    <table class="table table-hover mb-0" style="font-size:13px">
      <thead class="table-light">
        <tr><th>Kode</th><th>Nama</th><th>Kategori</th><th>Area</th><th>Status</th><th>PM Terakhir</th><th>PM Next</th></tr>
      </thead>
      <tbody>
        <?php foreach ($units as $u): 
          $catBadge = $u['category'] === 'Mekanikal' ? 'bg-warning text-dark' : 'bg-info';
          $statusText = isset($statusLabels[$u['status']]) ? $statusLabels[$u['status']] : $u['status'];
          $lastPM = $u['last_pm_date'] ? formatDate($u['last_pm_date']) : '-';
          $nextPM = $u['next_pm_date'] ? formatDate($u['next_pm_date']) : '-';
        ?>
        <tr>
          <td><strong><?php echo htmlspecialchars($u['code']); ?></strong></td>
          <td><?php echo htmlspecialchars($u['name']); ?></td>
          <td><span class="badge <?php echo $catBadge; ?>"><?php echo $u['category']; ?></span></td>
          <td><?php echo htmlspecialchars($u['area']); ?></td>
          <td><?php echo $statusText; ?></td>
          <td><?php echo $lastPM; ?></td>
          <td><strong><?php echo $nextPM; ?></strong></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
