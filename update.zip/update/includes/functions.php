<?php
/**
 * Helper Functions — PHP 7.0+ Compatible
 */
require_once __DIR__ . '/../config/database.php';

function getDBRStats() {
    $db = getDB();
    $stats = array('Open' => 0, 'In Progress' => 0, 'Pending Part' => 0, 'Monitoring' => 0, 'Closed' => 0);
    $rows = $db->query("SELECT status, COUNT(*) as cnt FROM dbr GROUP BY status")->fetchAll();
    foreach ($rows as $r) {
        if (isset($stats[$r['status']])) {
            $stats[$r['status']] = (int)$r['cnt'];
        }
    }
    $stats['total'] = array_sum($stats);
    $stats['open_total'] = $stats['Open'] + $stats['In Progress'] + $stats['Pending Part'];
    return $stats;
}

function getChecklistProgress($date = null) {
    $db = getDB();
    if ($date === null) $date = date('Y-m-d');
    $total = (int)$db->query("SELECT COUNT(*) FROM daily_checklist WHERE is_active = 1")->fetchColumn();
    $stmt = $db->prepare("SELECT COUNT(*) FROM daily_checklist_logs WHERE log_date = ? AND status = 'selesai'");
    $stmt->execute(array($date));
    $done = (int)$stmt->fetchColumn();
    $pct = $total > 0 ? round($done / $total * 100) : 0;
    return array('total' => $total, 'done' => $done, 'date' => $date, 'pct' => $pct);
}

function getEquipmentStats() {
    $db = getDB();
    $stats = array('running' => 0, 'maintenance' => 0, 'stopped' => 0, 'standby' => 0);
    $rows = $db->query("SELECT status, COUNT(*) as cnt FROM units GROUP BY status")->fetchAll();
    foreach ($rows as $r) {
        $stats[$r['status']] = (int)$r['cnt'];
    }
    $stats['total'] = array_sum($stats);
    return $stats;
}

function getMeterStats($date = null) {
    $db = getDB();
    if ($date === null) $date = date('Y-m-d');
    $total = (int)$db->query("SELECT COUNT(*) FROM meter_locations WHERE is_active = 1")->fetchColumn();
    $stmt = $db->prepare("SELECT COUNT(DISTINCT location_code) FROM meter_readings WHERE reading_date = ?");
    $stmt->execute(array($date));
    $recorded = (int)$stmt->fetchColumn();
    return array('total' => $total, 'recorded' => $recorded);
}

function getSparePartStats() {
    $db = getDB();
    $total = (int)$db->query("SELECT COUNT(*) FROM spare_parts")->fetchColumn();
    $low = (int)$db->query("SELECT COUNT(*) FROM spare_parts WHERE stock < min_stock")->fetchColumn();
    return array('total' => $total, 'low_stock' => $low);
}

function statusBadge($status) {
    $map = array(
        'Open'          => array('bg-amber-100', 'text-amber-800'),
        'In Progress'   => array('bg-blue-100', 'text-blue-800'),
        'Pending Part'  => array('bg-red-100', 'text-red-800'),
        'Closed'        => array('bg-emerald-100', 'text-emerald-800'),
        'Monitoring'    => array('bg-purple-100', 'text-purple-800'),
        'selesai'       => array('bg-emerald-100', 'text-emerald-800'),
        'belum'         => array('bg-gray-100', 'text-gray-600'),
    );
    if (isset($map[$status])) {
        $c = $map[$status];
    } else {
        $c = array('bg-gray-100', 'text-gray-800');
    }
    return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ' . $c[0] . ' ' . $c[1] . '"><span class="w-1.5 h-1.5 rounded-full bg-current opacity-50"></span>' . htmlspecialchars($status) . '</span>';
}

function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;
    if ($diff < 60) return 'Baru saja';
    if ($diff < 3600) return floor($diff / 60) . ' menit lalu';
    if ($diff < 86400) return floor($diff / 3600) . ' jam lalu';
    if ($diff < 604800) return floor($diff / 86400) . ' hari lalu';
    return date('d M Y, H:i', $timestamp);
}

function formatDate($date) {
    $months = array('', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des');
    $ts = strtotime($date);
    return date('d', $ts) . ' ' . $months[(int)date('m', $ts)] . ' ' . date('Y', $ts);
}

function redirect($url) {
    header("Location: $url");
    exit;
}
