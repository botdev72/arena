  </main></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function updateClock(){var d=new Date();var w=new Date(d.toLocaleString("en-US",{timeZone:"Asia/Jakarta"}));var days=["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];var months=["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];document.getElementById("liveClock").textContent=days[w.getDay()]+", "+w.getDate()+" "+months[w.getMonth()]+" "+w.getFullYear()+" — "+w.toTimeString().split(" ")[0]+" WIB"}updateClock();setInterval(updateClock,30000);
function showToast(msg,type){type=type||"info";var colors={success:"bg-success",error:"bg-danger",info:"bg-info",warning:"bg-warning text-dark"};var div=document.createElement("div");div.className="toast align-items-center text-white border-0 position-fixed bottom-0 end-0 m-3 "+(colors[type]||colors.info);div.setAttribute("role","alert");div.style.zIndex="9999";div.innerHTML='<div class="d-flex"><div class="toast-body fw-semibold" style="font-size:13px">'+msg+'</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>';document.body.appendChild(div);new bootstrap.Toast(div,{delay:3000}).show();setTimeout(function(){div.remove()},3500)}
function confirmDelete(msg){return confirm(msg||"Yakin ingin menghapus?")}
</script></body></html>
