<?php
/**
 * Authentication & Session Management
 * PHP 7.0+ Compatible
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/database.php';

function login($username, $password) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND active = 1 LIMIT 1");
    $stmt->execute(array($username));
    $user = $stmt->fetch();
    
    if (!$user) {
        return array('success' => false, 'error' => 'Username tidak ditemukan');
    }
    
    // Demo mode: accept password 'password123' or correct hash
    $valid = password_verify($password, $user['password_hash']) || $password === 'password123';
    
    if ($valid) {
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['username']  = $user['username'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role']      = $user['role'];
        $_SESSION['initials']  = $user['initials'];
        
        $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute(array($user['id']));
        return array('success' => true, 'user' => $user);
    }
    
    return array('success' => false, 'error' => 'Password salah');
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /login.php');
        exit;
    }
}

function currentUser() {
    if (!isLoggedIn()) return null;
    return array(
        'id'        => $_SESSION['user_id'],
        'username'  => $_SESSION['username'],
        'full_name' => $_SESSION['full_name'],
        'role'      => $_SESSION['role'],
        'initials'  => $_SESSION['initials'],
    );
}

function isSupervisor() {
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
    return $role === 'supervisor' || $role === 'admin';
}

function logout() {
    session_destroy();
    header('Location: /login.php');
    exit;
}
