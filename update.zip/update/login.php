<?php
require_once __DIR__ . '/includes/auth.php';
if (isLoggedIn()) { header('Location: /pages/dashboard.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? ''); $p = trim($_POST['password'] ?? '');
    if ($u && $p) { $r = login($u, $p); if ($r['success']) { header('Location: /pages/dashboard.php'); exit; } $error = $r['error']; }
    else $error = 'Username dan password wajib diisi';
}
?><!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Login — DBR & Maintenance | PT. RPH Garut</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{font-family:'Inter','Segoe UI',system-ui,sans-serif}</style></head>
<body class="d-flex align-items-center justify-content-center min-vh-100" style="background:linear-gradient(135deg,#1a3a5c 0%,#1e5799 50%,#0f243b 100%)">
<div class="card shadow-lg border-0" style="width:100%;max-width:420px;border-radius:16px"><div class="card-body p-4 p-md-5">
<div class="text-center mb-4"><div class="bg-primary rounded-3 d-inline-flex align-items-center justify-content-center mb-3" style="width:56px;height:56px"><span style="font-size:28px">⚡</span></div><h4 class="fw-bold">Maintenance System</h4><p class="text-muted" style="font-size:13px">PT. Raffles Pacific Harvest<br>Divisi Mechanical Electrical — Garut</p></div>
<?php if($error):?><div class="alert alert-danger py-2" style="font-size:13px">⚠️ <?=htmlspecialchars($error)?></div><?php endif?>
<form method="POST"><div class="mb-3"><label class="form-label fw-semibold" style="font-size:12px">Username</label><input type="text" name="username" class="form-control" placeholder="Masukkan username" value="<?=htmlspecialchars($_POST['username']??'')?>" required autofocus style="border-radius:8px"></div><div class="mb-3"><label class="form-label fw-semibold" style="font-size:12px">Password</label><input type="password" name="password" class="form-control" placeholder="Masukkan password" required style="border-radius:8px"></div><button type="submit" class="btn btn-primary w-100 py-2 fw-bold" style="border-radius:8px">🔐 Masuk ke Sistem</button></form>
<div class="text-center mt-4" style="font-size:11px;color:#888"><p class="mb-0 fw-semibold">Demo Accounts:</p><code>admin</code> · <code>budi</code> · <code>dedi</code> · <code>agus</code><br>Password: <code>password123</code></div></div></div></body></html>
