-- DBR & Maintenance System — PT. RPH Garut — MySQL Schema
CREATE DATABASE IF NOT EXISTS rph_me_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rph_me_db;

CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) UNIQUE NOT NULL, password_hash VARCHAR(255) NOT NULL, full_name VARCHAR(100) NOT NULL, role ENUM("supervisor","teknisi","admin") DEFAULT "teknisi", initials VARCHAR(5) NOT NULL, active TINYINT(1) DEFAULT 1, last_login DATETIME, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;

CREATE TABLE units (id INT AUTO_INCREMENT PRIMARY KEY, code VARCHAR(20) UNIQUE NOT NULL, name VARCHAR(100) NOT NULL, category ENUM("Mekanikal","Elektrikal") NOT NULL, area VARCHAR(100) NOT NULL, status ENUM("running","maintenance","stopped","standby") DEFAULT "running", last_pm_date DATE, next_pm_date DATE, notes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB;

CREATE TABLE dbr (id INT AUTO_INCREMENT PRIMARY KEY, dbr_number VARCHAR(20) UNIQUE NOT NULL, unit_id INT NOT NULL, category ENUM("Mekanikal","Elektrikal") NOT NULL, down_date DATE NOT NULL, down_hm INT DEFAULT 0, down_time TIME NOT NULL, ready_date DATE, ready_hm INT DEFAULT 0, ready_time TIME, problem TEXT NOT NULL, action TEXT NOT NULL, pic VARCHAR(100), status ENUM("Open","In Progress","Pending Part","Closed","Monitoring") DEFAULT "Open", keterangan TEXT, created_by VARCHAR(50), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, FOREIGN KEY (unit_id) REFERENCES units(id) ON DELETE CASCADE) ENGINE=InnoDB;

CREATE TABLE daily_checklist (id INT AUTO_INCREMENT PRIMARY KEY, task_name VARCHAR(200) NOT NULL, description TEXT, area VARCHAR(100) NOT NULL, schedule_info VARCHAR(100) NOT NULL, is_active TINYINT(1) DEFAULT 1, sort_order INT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;

CREATE TABLE daily_checklist_logs (id INT AUTO_INCREMENT PRIMARY KEY, checklist_id INT NOT NULL, log_date DATE NOT NULL, status ENUM("selesai","belum") DEFAULT "belum", pic VARCHAR(100), completed_at DATETIME, notes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY unique_log (checklist_id, log_date), FOREIGN KEY (checklist_id) REFERENCES daily_checklist(id) ON DELETE CASCADE) ENGINE=InnoDB;

CREATE TABLE meter_locations (id INT AUTO_INCREMENT PRIMARY KEY, code VARCHAR(20) UNIQUE NOT NULL, name VARCHAR(100) NOT NULL, meter_type ENUM("listrik","air","bahan_bakar") NOT NULL, unit VARCHAR(20) NOT NULL, is_active TINYINT(1) DEFAULT 1, sort_order INT DEFAULT 0) ENGINE=InnoDB;

CREATE TABLE meter_readings (id INT AUTO_INCREMENT PRIMARY KEY, reading_date DATE NOT NULL, location_code VARCHAR(20) NOT NULL, meter_type ENUM("listrik","air","bahan_bakar") NOT NULL, meter_value DECIMAL(12,2) NOT NULL, usage_value DECIMAL(12,2) DEFAULT 0, pic VARCHAR(100), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY unique_reading (reading_date, location_code), FOREIGN KEY (location_code) REFERENCES meter_locations(code) ON DELETE CASCADE) ENGINE=InnoDB;

CREATE TABLE spare_parts (id INT AUTO_INCREMENT PRIMARY KEY, code VARCHAR(30) UNIQUE NOT NULL, name VARCHAR(150) NOT NULL, category VARCHAR(50) NOT NULL, stock INT NOT NULL DEFAULT 0, min_stock INT NOT NULL DEFAULT 5, unit VARCHAR(20) DEFAULT "pcs", location VARCHAR(100), last_restock DATE, notes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB;

CREATE TABLE activity_logs (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, action VARCHAR(50) NOT NULL, entity_type VARCHAR(50), entity_id INT, description TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB;
