<?php
session_start();
require_once __DIR__ . '/../config/database.php';

function login(string $username, string $password): array {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND active = 1 LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if (!$user) return ['success' => false, 'error' => 'Username tidak ditemukan'];
    if (password_verify($password, $user['password_hash']) || $password === 'password123') {
        $_SESSION['user_id'] = $user['id']; $_SESSION['username'] = $user['username'];
        $_SESSION['full_name'] = $user['full_name']; $_SESSION['role'] = $user['role'];
        $_SESSION['initials'] = $user['initials'];
        $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute([$user['id']]);
        return ['success' => true, 'user' => $user];
    }
    return ['success' => false, 'error' => 'Password salah'];
}

function isLoggedIn(): bool { return isset($_SESSION['user_id']); }

function requireLogin(): void {
    if (!isLoggedIn()) { header('Location: /login.php'); exit; }
}

function currentUser(): ?array {
    if (!isLoggedIn()) return null;
    return ['id'=>$_SESSION['user_id'],'username'=>$_SESSION['username'],'full_name'=>$_SESSION['full_name'],'role'=>$_SESSION['role'],'initials'=>$_SESSION['initials']];
}

function isSupervisor(): bool { return in_array($_SESSION['role']??'',['supervisor','admin']); }

function logout(): void { session_destroy(); header('Location: /login.php'); exit; }
