<?php
require_once __DIR__ . '/../config/database.php';

function getDBRStats(): array {
    $db = getDB(); $s = ['Open'=>0,'In Progress'=>0,'Pending Part'=>0,'Monitoring'=>0,'Closed'=>0];
    foreach ($db->query("SELECT status, COUNT(*) as cnt FROM dbr GROUP BY status") as $r) if (isset($s[$r['status']])) $s[$r['status']]=(int)$r['cnt'];
    $s['total']=array_sum($s); $s['open_total']=$s['Open']+$s['In Progress']+$s['Pending Part'];
    return $s;
}

function getChecklistProgress(string $date=null): array {
    $db=getDB(); $date=$date??date('Y-m-d');
    $total=(int)$db->query("SELECT COUNT(*) FROM daily_checklist WHERE is_active=1")->fetchColumn();
    $s=$db->prepare("SELECT COUNT(*) FROM daily_checklist_logs WHERE log_date=? AND status='selesai'"); $s->execute([$date]);
    $done=(int)$s->fetchColumn();
    return ['total'=>$total,'done'=>$done,'date'=>$date,'pct'=>$total>0?round($done/$total*100):0];
}

function getEquipmentStats(): array {
    $db=getDB(); $s=['running'=>0,'maintenance'=>0,'stopped'=>0,'standby'=>0];
    foreach ($db->query("SELECT status, COUNT(*) as cnt FROM units GROUP BY status") as $r) $s[$r['status']]=(int)$r['cnt'];
    $s['total']=array_sum($s); return $s;
}

function getMeterStats(string $date=null): array {
    $db=getDB(); $date=$date??date('Y-m-d');
    $total=(int)$db->query("SELECT COUNT(*) FROM meter_locations WHERE is_active=1")->fetchColumn();
    $s=$db->prepare("SELECT COUNT(DISTINCT location_code) FROM meter_readings WHERE reading_date=?"); $s->execute([$date]);
    return ['total'=>$total,'recorded'=>(int)$s->fetchColumn()];
}

function getSparePartStats(): array {
    $db=getDB();
    return ['total'=>(int)$db->query("SELECT COUNT(*) FROM spare_parts")->fetchColumn(),'low_stock'=>(int)$db->query("SELECT COUNT(*) FROM spare_parts WHERE stock < min_stock")->fetchColumn()];
}

function statusBadge(string $status): string {
    $m=['Open'=>['bg-amber-100','text-amber-800','bg-amber-500'],'In Progress'=>['bg-blue-100','text-blue-800','bg-blue-500'],'Pending Part'=>['bg-red-100','text-red-800','bg-red-500'],'Closed'=>['bg-emerald-100','text-emerald-800','bg-emerald-500'],'Monitoring'=>['bg-purple-100','text-purple-800','bg-purple-500'],'selesai'=>['bg-emerald-100','text-emerald-800','bg-emerald-500'],'belum'=>['bg-gray-100','text-gray-600','bg-gray-400']];
    $s=$m[$status]??['bg-gray-100','text-gray-800','bg-gray-500'];
    return sprintf('<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold %s %s"><span class="w-1.5 h-1.5 rounded-full %s"></span>%s</span>',$s[0],$s[1],$s[2],$status);
}

function timeAgo(string $dt): string {
    $diff=time()-strtotime($dt); if($diff<60)return'Baru saja'; if($diff<3600)return floor($diff/60).' menit lalu';
    if($diff<86400)return floor($diff/3600).' jam lalu'; if($diff<604800)return floor($diff/86400).' hari lalu';
    return date('d M Y, H:i',strtotime($dt));
}

function formatDate(string $d): string { $m=['','Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des']; $t=strtotime($d); return date('d',$t).' '.$m[(int)date('m',$t)].' '.date('Y',$t); }
function redirect(string $url): void { header("Location: $url"); exit; }
