  </main></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function updateClock(){var d=new Date(),w=new Date(d.toLocaleString('en-US',{timeZone:'Asia/Jakarta'}));document.getElementById('liveClock').textContent=['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][w.getDay()]+', '+w.getDate()+' '+['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'][w.getMonth()]+' '+w.getFullYear()+' — '+w.toTimeString().split(' ')[0]+' WIB'}updateClock();setInterval(updateClock,30000);
function showToast(m,t){t=t||'info';var c={success:'bg-success',error:'bg-danger',info:'bg-info',warning:'bg-warning text-dark'};var e=document.createElement('div');e.className='toast align-items-center text-white border-0 position-fixed bottom-0 end-0 m-3 '+(c[t]||c.info);e.setAttribute('role','alert');e.style.zIndex='9999';e.innerHTML='<div class="d-flex"><div class="toast-body fw-semibold" style="font-size:13px">'+m+'</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>';document.body.appendChild(e);new bootstrap.Toast(e,{delay:3000}).show();setTimeout(function(){e.remove()},3500)}
function confirmDelete(m){return confirm(m||'Yakin ingin menghapus?')}
</script></body></html>
