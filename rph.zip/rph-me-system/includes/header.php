<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
$user = currentUser();
$pageTitle = $pageTitle ?? 'Dashboard';
$activePage = $activePage ?? 'dashboard';
?><!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?> — DBR & Maintenance | PT. RPH Garut</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>tailwind.config={theme:{extend:{colors:{navy:{700:'#1a3a5c',800:'#152e4a',900:'#0f243b'},accent:{500:'#1e5799',600:'#1a4a82'}}}}}</script>
<style>body{font-family:'Inter','Segoe UI',system-ui,sans-serif;background:#f0f2f5;min-height:100vh}.sidebar{width:260px;min-height:100vh;transition:transform .2s}.nav-link-custom{transition:all .15s;border-radius:6px;margin-bottom:2px}.nav-link-custom:hover{background:rgba(255,255,255,.08)}.nav-link-custom.active{background:rgba(255,255,255,.15);font-weight:600}.card-stat{transition:all .15s;cursor:pointer}.card-stat:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.1)}@media(max-width:991.98px){.sidebar{position:fixed;z-index:1040;transform:translateX(-100%)}.sidebar.open{transform:translateX(0)}}</style>
</head>
<body class="d-flex">
<aside class="sidebar bg-navy-800 text-white d-flex flex-column flex-shrink-0" id="sidebar">
<div class="d-flex align-items-center gap-2 px-3 py-3 border-bottom border-white border-opacity-10">
<div class="bg-accent-500 rounded-2 d-flex align-items-center justify-content-center" style="width:38px;height:38px"><span class="fw-bold fs-5">⚡</span></div>
<div class="lh-sm"><div class="fw-bold" style="font-size:14px">RPH MMS</div><div class="text-white-50" style="font-size:10px">ME Division · Garut</div></div></div>
<nav class="flex-grow-1 overflow-auto px-2 py-3">
<div class="text-white-50 text-uppercase px-2 py-2" style="font-size:10px;letter-spacing:.08em">Menu Utama</div>
<a href="/pages/dashboard.php" class="nav-link-custom d-flex align-items-center gap-2 px-3 py-2 text-white text-decoration-none <?= $activePage==='dashboard'?'active':'' ?>"><span>📊</span> Dashboard</a>
<a href="/pages/dbr/" class="nav-link-custom d-flex align-items-center gap-2 px-3 py-2 text-white text-decoration-none <?= $activePage==='dbr'?'active':'' ?>"><span>🔴</span> Laporan DBR<?php $o=getDBRStats()['open_total']; if($o):?><span class="badge bg-warning text-dark ms-auto"><?=$o?></span><?php endif;?></a>
<a href="/pages/checklist.php" class="nav-link-custom d-flex align-items-center gap-2 px-3 py-2 text-white text-decoration-none <?= $activePage==='checklist'?'active':'' ?>"><span>✅</span> Checklist Harian</a>
<a href="/pages/meteran.php" class="nav-link-custom d-flex align-items-center gap-2 px-3 py-2 text-white text-decoration-none <?= $activePage==='meteran'?'active':'' ?>"><span>💧</span> Catatan Meteran</a>
<a href="/pages/spareparts.php" class="nav-link-custom d-flex align-items-center gap-2 px-3 py-2 text-white text-decoration-none <?= $activePage==='spareparts'?'active':'' ?>"><span>📦</span> Spare Parts<?php $l=getSparePartStats()['low_stock']; if($l):?><span class="badge bg-danger ms-auto"><?=$l?></span><?php endif;?></a>
<div class="text-white-50 text-uppercase px-2 py-2 mt-2" style="font-size:10px;letter-spacing:.08em">Manajemen</div>
<a href="/pages/equipment.php" class="nav-link-custom d-flex align-items-center gap-2 px-3 py-2 text-white text-decoration-none <?= $activePage==='equipment'?'active':'' ?>"><span>⚙️</span> Peralatan</a>
<a href="/pages/reports.php" class="nav-link-custom d-flex align-items-center gap-2 px-3 py-2 text-white text-decoration-none <?= $activePage==='reports'?'active':'' ?>"><span>📈</span> Laporan</a>
</nav>
<div class="border-top border-white border-opacity-10 p-3 d-flex align-items-center gap-2">
<div class="bg-accent-500 rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width:36px;height:36px;font-size:13px"><?=$user['initials']?></div>
<div class="lh-sm" style="font-size:12px"><div class="fw-semibold"><?=htmlspecialchars($user['full_name'])?></div><div class="text-white-50" style="font-size:10px"><?=ucfirst($user['role'])?></div></div>
<a href="/logout.php" class="ms-auto text-white-50 text-decoration-none">🚪</a></div>
</aside>
<div class="flex-grow-1 d-flex flex-column min-vh-100" style="margin-left:0">
<nav class="navbar navbar-dark bg-navy-700 px-3 py-2 sticky-top shadow-sm" style="min-height:56px">
<div class="d-flex align-items-center gap-2">
<button class="btn btn-sm text-white border-0 d-lg-none" onclick="document.getElementById('sidebar').classList.toggle('open')" style="font-size:20px">☰</button>
<div><div class="fw-bold" style="font-size:16px"><?=htmlspecialchars($pageTitle)?></div><div class="text-white-50" style="font-size:11px">PT. Raffles Pacific Harvest — Divisi Mechanical Electrical</div></div></div>
<div class="d-flex align-items-center gap-3"><span class="text-white-50" style="font-size:12px" id="liveClock"></span><span class="badge bg-light text-dark" style="font-size:11px"><?=date('d M Y')?></span></div>
</nav>
<main class="flex-grow-1 p-3 p-md-4">
