<?php
$pageTitle='Checklist Harian';$activePage='checklist';
require_once __DIR__.'/../includes/header.php';
$db=getDB();$today=date('Y-m-d');
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['mark_done'])){
 $cid=(int)$_POST['checklist_id'];$pic=$_POST['pic']?:currentUser()['full_name'];
 $ex=$db->prepare("SELECT id FROM daily_checklist_logs WHERE checklist_id=? AND log_date=?");$ex->execute([$cid,$today]);
 if($ex->fetch()){$db->prepare("UPDATE daily_checklist_logs SET status='selesai',pic=?,completed_at=NOW() WHERE checklist_id=? AND log_date=?")->execute([$pic,$cid,$today]);}
 else{$db->prepare("INSERT INTO daily_checklist_logs(checklist_id,log_date,status,pic,completed_at) VALUES(?,?,?,?,NOW())")->execute([$cid,$today,'selesai',$pic]);}
 echo "<script>showToast('✅ Checklist selesai!','success')</script>";
}
$items=$db->query("SELECT dc.*,dl.status as log_status,dl.pic as log_pic,dl.completed_at FROM daily_checklist dc LEFT JOIN daily_checklist_logs dl ON dc.id=dl.checklist_id AND dl.log_date='$today' WHERE dc.is_active=1 ORDER BY dc.sort_order")->fetchAll();
$total=count($items);$done=count(array_filter($items,fn($i)=>$i['log_status']==='selesai'));$pct=$total>0?round($done/$total*100):0;
?>
<div class="alert alert-info d-flex align-items-center gap-2" style="font-size:13px">📌 Checklist harian wajib diisi setiap hari kerja. Jika ditemukan masalah, segera laporkan melalui tombol <strong>⚠️ Lapor DBR</strong>.</div>
<div class="card border-0 shadow-sm mb-4" style="border-radius:12px"><div class="card-body"><div class="d-flex justify-content-between align-items-center mb-2"><span class="fw-bold">Progres Hari Ini — <?=formatDate($today)?></span><span class="fw-bold"><?=$done?>/<?=$total?> Selesai (<?=$pct?>%)</span></div><div class="progress" style="height:10px;border-radius:5px"><div class="progress-bar <?=$pct===100?'bg-success':'bg-primary'?>" style="width:<?=$pct?>%;transition:width 0.5s"></div></div></div></div>
<div class="card border-0 shadow-sm" style="border-radius:12px"><div class="list-group list-group-flush"><?php foreach($items as $it):$is=$it['log_status']==='selesai';?><div class="list-group-item d-flex align-items-center justify-content-between gap-3 py-3 px-3"><div class="flex-grow-1" style="min-width:0"><div class="fw-semibold" style="font-size:13px"><?=htmlspecialchars($it['task_name'])?></div><div class="text-muted" style="font-size:11px"><?=$it['schedule_info']?> · <?=$it['area']?></div><?php if($is):?><div class="text-success mt-1" style="font-size:11px">✅ Selesai oleh <strong><?=htmlspecialchars($it['log_pic'])?></strong> — <?=timeAgo($it['completed_at'])?></div><?php endif;?></div><div class="d-flex align-items-center gap-2 flex-shrink-0"><span class="badge <?=$is?'bg-success':'bg-light text-secondary'?>" style="font-size:10px"><?=$is?'✓ Selesai':'✗ Belum'?></span><?php if(!$is):?><form method="POST" class="d-flex align-items-center gap-2"><input type="hidden" name="checklist_id" value="<?=$it['id']?>"><select name="pic" class="form-select form-select-sm" style="font-size:11px;width:130px"><option>Pilih PIC</option><option>Budi Santoso</option><option>Dedi Kurniawan</option><option>Agus Prasetyo</option><option>Andi Rahman</option></select><button type="submit" name="mark_done" class="btn btn-success btn-sm" style="font-size:11px">✓ Selesai</button><a href="/pages/dbr/" class="btn btn-danger btn-sm" style="font-size:11px">⚠️ Lapor DBR</a></form><?php endif;?></div></div><?php endforeach;?></div></div>
<?php require_once __DIR__.'/../includes/footer.php';?>
